module.exports=[74081,(a,b,c)=>{}];

//# sourceMappingURL=cs-api__next-internal_server_app_page_actions_79134d86.js.map
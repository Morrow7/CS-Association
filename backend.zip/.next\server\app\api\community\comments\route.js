var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/community/comments/route.js")
R.c("server/chunks/[root-of-the-server]__7a4cfc26._.js")
R.c("server/chunks/[root-of-the-server]__3078c16f._.js")
R.c("server/chunks/[root-of-the-server]__9f2fdb24._.js")
R.c("server/chunks/cs-api__next-internal_server_app_api_community_comments_route_actions_405469c8.js")
R.m(59679)
module.exports=R.m(59679).exports

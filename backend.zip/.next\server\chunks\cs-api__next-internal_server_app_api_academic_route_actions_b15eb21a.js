module.exports=[21592,(e,o,d)=>{}];

//# sourceMappingURL=cs-api__next-internal_server_app_api_academic_route_actions_b15eb21a.js.map
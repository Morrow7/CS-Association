1:"$Sreact.fragment"
2:I[53911,["/_next/static/chunks/c6a299ceb708432d.js"],"default"]
3:I[97453,["/_next/static/chunks/c6a299ceb708432d.js"],"default"]
0:{"buildId":"cMODE-pMcHzeVUfyf-Wyu","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}

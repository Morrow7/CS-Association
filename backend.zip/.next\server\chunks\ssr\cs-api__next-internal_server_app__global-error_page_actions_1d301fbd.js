module.exports=[45724,(a,b,c)=>{}];

//# sourceMappingURL=cs-api__next-internal_server_app__global-error_page_actions_1d301fbd.js.map
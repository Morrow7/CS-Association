1:"$Sreact.fragment"
2:I[13788,["/_next/static/chunks/c6a299ceb708432d.js"],"OutletBoundary"]
3:"$Sreact.suspense"
0:{"buildId":"cMODE-pMcHzeVUfyf-Wyu","rsc":["$","$1","c",{"children":[["$","main",null,{"style":{"minHeight":"100vh","padding":"64px 24px","backgroundColor":"#020617","color":"#e5e7eb","display":"flex","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"style":{"maxWidth":"960px","width":"100%","textAlign":"center"},"children":[["$","h1",null,{"style":{"fontSize":"40px","marginBottom":"16px"},"children":"CS-Association"}],["$","p",null,{"style":{"fontSize":"18px","marginBottom":"24px"},"children":"这里是协会的主页。后续可以根据需要迁移原有的卡片和动效。"}]]}]}],null,["$","$L2",null,{"children":["$","$3",null,{"name":"Next.MetadataOutlet","children":"$@4"}]}]]}],"loading":null,"isPartial":false}
4:null

var R=require("../../chunks/[turbopack]_runtime.js")("server/app/api/route.js")
R.c("server/chunks/[root-of-the-server]__4b19b479._.js")
R.c("server/chunks/[root-of-the-server]__3078c16f._.js")
R.c("server/chunks/[root-of-the-server]__9f2fdb24._.js")
R.c("server/chunks/cs-api__next-internal_server_app_api_route_actions_38fba8d1.js")
R.m(24315)
module.exports=R.m(24315).exports

var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/community/route.js")
R.c("server/chunks/[root-of-the-server]__bd96e530._.js")
R.c("server/chunks/[root-of-the-server]__3078c16f._.js")
R.c("server/chunks/[root-of-the-server]__9f2fdb24._.js")
R.c("server/chunks/cs-api__next-internal_server_app_api_community_route_actions_ba18e5fc.js")
R.m(94268)
module.exports=R.m(94268).exports

module.exports=[27515,(e,o,d)=>{}];

//# sourceMappingURL=cs-api__next-internal_server_app_api_community_route_actions_ba18e5fc.js.map
var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_b01ab6e1._.js")
R.c("server/chunks/[root-of-the-server]__9f2fdb24._.js")
R.c("server/chunks/abfa9_next_dist_esm_build_templates_app-route_45bef46a.js")
R.c("server/chunks/cs-api__next-internal_server_app_favicon_ico_route_actions_806b8cf4.js")
R.m(46195)
module.exports=R.m(46195).exports

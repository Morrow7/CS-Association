module.exports=[33474,(a,b,c)=>{}];

//# sourceMappingURL=cs-api__next-internal_server_app_landing_page_actions_f99c0967.js.map
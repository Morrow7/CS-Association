var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/login/route.js")
R.c("server/chunks/[root-of-the-server]__8e03ed6b._.js")
R.c("server/chunks/4fa2d_bcryptjs_18935554._.js")
R.c("server/chunks/[root-of-the-server]__9f2fdb24._.js")
R.c("server/chunks/[root-of-the-server]__56c9b894._.js")
R.c("server/chunks/cs-api__next-internal_server_app_api_login_route_actions_97c7147f.js")
R.m(99512)
module.exports=R.m(99512).exports

var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/register/route.js")
R.c("server/chunks/[root-of-the-server]__a2752610._.js")
R.c("server/chunks/4fa2d_bcryptjs_18935554._.js")
R.c("server/chunks/[root-of-the-server]__9f2fdb24._.js")
R.c("server/chunks/[root-of-the-server]__56c9b894._.js")
R.c("server/chunks/cs-api__next-internal_server_app_api_register_route_actions_5664733f.js")
R.m(88006)
module.exports=R.m(88006).exports

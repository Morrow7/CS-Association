var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/github/login/route.js")
R.c("server/chunks/[root-of-the-server]__4a36e7cf._.js")
R.c("server/chunks/[root-of-the-server]__9f2fdb24._.js")
R.c("server/chunks/cs-api__next-internal_server_app_api_github_login_route_actions_cedf2838.js")
R.m(44920)
module.exports=R.m(44920).exports

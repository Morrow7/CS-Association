module.exports=[19169,(e,o,d)=>{}];

//# sourceMappingURL=cs-api__next-internal_server_app_api_github_login_route_actions_cedf2838.js.map
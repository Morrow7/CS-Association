var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/academic/route.js")
R.c("server/chunks/[root-of-the-server]__7d40ce0e._.js")
R.c("server/chunks/[root-of-the-server]__3078c16f._.js")
R.c("server/chunks/[root-of-the-server]__9f2fdb24._.js")
R.c("server/chunks/cs-api__next-internal_server_app_api_academic_route_actions_b15eb21a.js")
R.m(82879)
module.exports=R.m(82879).exports

module.exports=[58526,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},59543,a=>{"use strict";let b={src:a.i(58526).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=cs-api_src_app_a96a4e17._.js.map
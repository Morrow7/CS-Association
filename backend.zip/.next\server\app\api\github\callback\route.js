var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/github/callback/route.js")
R.c("server/chunks/[root-of-the-server]__00d6ae1b._.js")
R.c("server/chunks/4fa2d_bcryptjs_18935554._.js")
R.c("server/chunks/[root-of-the-server]__9f2fdb24._.js")
R.c("server/chunks/[root-of-the-server]__56c9b894._.js")
R.c("server/chunks/abfa9_next_a85fbaa0._.js")
R.c("server/chunks/cs-api__next-internal_server_app_api_github_callback_route_actions_af73b28a.js")
R.m(45233)
module.exports=R.m(45233).exports

module.exports=[3198,(e,o,d)=>{}];

//# sourceMappingURL=cs-api__next-internal_server_app_favicon_ico_route_actions_806b8cf4.js.map
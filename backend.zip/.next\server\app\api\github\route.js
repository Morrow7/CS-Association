var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/github/route.js")
R.c("server/chunks/[root-of-the-server]__8428e278._.js")
R.c("server/chunks/4fa2d_bcryptjs_18935554._.js")
R.c("server/chunks/[root-of-the-server]__9f2fdb24._.js")
R.c("server/chunks/[root-of-the-server]__56c9b894._.js")
R.c("server/chunks/abfa9_next_a85fbaa0._.js")
R.c("server/chunks/cs-api__next-internal_server_app_api_github_route_actions_9a91805c.js")
R.m(13454)
module.exports=R.m(13454).exports

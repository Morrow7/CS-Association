globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/c018ff2de26e5bba.js",
    "static/chunks/3a42f2734839fe51.js",
    "static/chunks/71d4a2fcfe178ba2.js",
    "static/chunks/7a2f079f73ecffeb.js",
    "static/chunks/turbopack-f17e4b2597987832.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];